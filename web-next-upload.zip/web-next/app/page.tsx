export default async function Home() {
  const api = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000';
  const kpis = await fetch(api + '/kpis', { cache: 'no-store' }).then(r=>r.json()).catch(()=>({}));
  return (
    <main>
      <h1>Admin — Painel inicial</h1>
      <pre>{JSON.stringify(kpis,null,2)}</pre>
    </main>
  );
}
