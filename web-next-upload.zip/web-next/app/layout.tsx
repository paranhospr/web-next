export const metadata = { title: 'Paranhos — Admin' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-br">
      <body style={{fontFamily:'system-ui,Arial', padding:20, maxWidth:1000, margin:'0 auto'}}>
        <nav style={{display:'flex',gap:16,marginBottom:20}}>
          <a href="/(admin)/municipalities">Municípios</a>
          <a href="/(admin)/xmas">Solicitações Natal</a>
        </nav>
        {children}
      </body>
    </html>
  );
}
